
#ifndef	__TOTAL_H
#define __TOTAL_H

#include "reg52.h"
#include "intrins.h"
#include "lcd.h"
#include "DS1302.h"

#define uint unsigned int
#define uchar unsigned char
#define nop() _nop_()



#endif









